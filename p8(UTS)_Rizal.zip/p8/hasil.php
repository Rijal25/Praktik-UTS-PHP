<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title></title>
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <style>
        .border {
            border: 1px solid;
            height: 55px;
            border-radius: 3px;
        }
    </style>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4"><b>MEDICAL FORM</b></h3></div>
                                    <div class="card-body">
                                        <form>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['namaAwal']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['namaAkhir'] ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['umur']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['gender']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-12">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['email']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['agama']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['pendidikan']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['kota']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['provinsi']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 600px; margin: 0 auto; box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">
                                                <div class="card-header"><h3 class="text-center font-weight-light my-4"><b>MEDICAL CHECK FORM</b></h3></div>
                                                <div class="card-body">
                                                    <div class="form-group row">
                                                        <label class="col-12">Periksa ketentuan yang berlaku untuk Anda atau anggota kerabat dekat Anda:</label> 
                                                        <div class="col-12">
                                                            <div class="border">
                                                                <p class="mt-2 ms-2">
                                                                    <?php echo $_POST['ketentuan']; ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div> <br>
                                                    <div class="form-group row">
                                                        <label class="col-12">Periksa gejala yang Anda alami saat ini.</label> 
                                                        <div class="col-12">
                                                            <div class="border">
                                                                <p class="mt-2 ms-2">
                                                                    <?php echo $_POST['gejala']; ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div> <br>
                                                    <div class="form-group row">
                                                        <label class="col-12">Apakah saat ini Anda sedang mengonsumsi obat?</label> 
                                                         <div class="col-12">
                                                            <div class="border">
                                                                <p class="mt-2 ms-2">
                                                                    <?php echo $_POST['keterangan']; ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-12">Silahkan lihat yang lain.</label> 
                                                        <div class="col-12">
                                                            <div class="border">
                                                                <p class="mt-2 ms-2">
                                                                    <?php echo $_POST['lainnya']; ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>         
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <h3>Take care of your Health</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>