<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title></title>
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4"><b>MEDICAL FORM</b></h3></div>
                                    <div class="card-body">
                                        <form action="hasil.php" method="POST">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="inputFirstName" type="text" placeholder="Enter your first name" name="namaAwal"/>
                                                         <label for="inputFirstName">First name</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" id="inputLastName" type="text" placeholder="Enter your last name" name="namaAkhir" />
                                                        <label for="inputLastName">Last name</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="inputUmur" type="text" placeholder="Enter your first name" name="umur" />
                                                        <label for="inputUmur">What is a your age?</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <div class="custom-control custom-radio custom-control-inline">
                                                            <input name="gender" id="inputGender_0" type="radio" class="custom-control-input" value="Laki-laki"> 
                                                            <label for="inputGender_0" class="custom-control-label">Laki-laki</label>
                                                        </div>
                                                        <div class="custom-control custom-radio custom-control-inline">
                                                            <input name="gender" id="inputGender_1" type="radio" class="custom-control-input" value="Perempuan"> 
                                                            <label for="inputGender_1" class="custom-control-label">Perempuan</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEmail" type="email" placeholder="name@example.com" name="email" />
                                                <label for="inputEmail">Email address</label>
                                            </div>
                                             <div class="row mb-3">
                                                 <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <label for="agama"></label> 
                                                        <select id="agama" name="agama" class="custom-select">
                                                            <option value="agama">Agama</option>
                                                            <option value="Islam">Islam</option>
                                                            <option value="Kristen">Kristen</option>
                                                            <option value="Hindu">Hindu</option>
                                                            <option value="Budha">Budha</option>  
                                                        </select>
                                                    </div> 
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <label for="pendidikan"></label> 
                                                        <select id="pendidikan" name="pendidikan" class="custom-select">
                                                            <option value="JP">Jenjang Pendidikan</option>
                                                            <option value="SD">SD</option>
                                                            <option value="SMP">SMP</option>
                                                            <option value="SMA">SMA</option>
                                                            <option value="D1">D1</option>
                                                            <option value="D2">D2</option>
                                                            <option value="D3">D3</option>
                                                            <option value="S1">S1</option>
                                                            <option value="S2">S2</option>
                                                            <option value="S3">S3</option>
                                                        </select>
                                                    </div>  
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="inputKota" type="text" placeholder="Create kota" name="kota" />
                                                        <label for="inputKota">Nama Kota</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="inputProvinsi" type="text" placeholder="Confirm provinsi" name="provinsi" />
                                                        <label for="inputProvinsi">Nama Provinsi</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 600px; margin: 0 auto; box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">
                                                <div class="card-header"><h3 class="text-center font-weight-light my-4"><b>MEDICAL CHECK FORM</b></h3></div>
                                                <div class="card-body">
                                                        <div class="form-group row">
                                                            <label class="col-12">Periksa ketentuan yang berlaku untuk Anda atau anggota kerabat dekat Anda:</label> 
                                                            <div class="col-12">
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="ketentuan" id="ketentuan_0" type="checkbox" class="custom-control-input" value="Koma"> 
                                                                    <label for="ketentuan_0" class="custom-control-label">Koma</label>
                                                                </div>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="ketentuan" id="ketentuan_1" type="checkbox" class="custom-control-input" value="Jantung"> 
                                                                    <label for="ketentuan_1" class="custom-control-label">Penyakit Jantung</label>
                                                                </div>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="ketentuan" id="ketentuan_2" type="checkbox" class="custom-control-input" value="Kanker"> 
                                                                    <label for="ketentuan_2" class="custom-control-label">Kanker</label>
                                                                </div>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="ketentuan" id="ketentuan_3" type="checkbox" class="custom-control-input" value="Diabetes"> 
                                                                    <label for="ketentuan_3" class="custom-control-label">Diabetes</label>
                                                                </div>
                                                            </div>
                                                        </div> <br>
                                                        <div class="form-group row">
                                                            <label class="col-12">Periksa gejala yang Anda alami saat ini.</label> 
                                                            <div class="col-12">
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="gejala" id="gejala_0" type="checkbox" class="custom-control-input" value="Sakit Dada"> 
                                                                    <label for="gejala_0" class="custom-control-label">Sakit Dada</label>
                                                                </div>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="gejala" id="gejala_1" type="checkbox" class="custom-control-input" value="Kardiovaskular"> 
                                                                    <label for="gejala_1" class="custom-control-label">Kardiovaskular</label>
                                                                </div>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="gejala" id="gejala_2" type="checkbox" class="custom-control-input" value="Pernapasan"> 
                                                                    <label for="gejala_2" class="custom-control-label">Pernapasan</label>
                                                                </div>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input name="gejala" id="gejala_3" type="checkbox" class="custom-control-input" value="Berat Badan"> 
                                                                    <label for="gejala_3" class="custom-control-label">Penambahan BB</label>
                                                                </div>
                                                            </div>
                                                        </div> <br>
                                                        <div class="form-group row">
                                                            <label class="col-12">Apakah saat ini Anda sedang mengonsumsi obat?</label> 
                                                            <div class="col-12">
                                                                <div class="custom-control custom-radio custom-control-inline">
                                                                    <input name="keterangan" id="keterangan_0" type="radio" class="custom-control-input" value="ya"> 
                                                                    <label for="keterangan_0" class="custom-control-label">Ya</label>
                                                                </div>
                                                                <div class="custom-control custom-radio custom-control-inline">
                                                                    <input name="keterangan" id="keterangan_1" type="radio" class="custom-control-input" value="tidak"> 
                                                                    <label for="keterangan_1" class="custom-control-label">Tidak</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="lainnya" class="col-12">Silahkan lihat yang lain.</label> 
                                                            <div class="col-12">
                                                                <textarea id="lainnya" name="lainnya" cols="40" rows="" class="form-control"></textarea>
                                                            </div>
                                                        </div>         
                                                </div>
                                            </div>
                                            <div>
                                                 <div class="d-grid"><input class="btn btn-primary btn-block"  type="submit" value="Submit" name="submit" /></div>
                                            </div> 
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <h3>Take care of your Health</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
